<?php $__env->startSection('title-block'); ?>
    Update page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Update page</h1>

    <form action="<?php echo e(route('contact-update-submit', $data->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" value='<?php echo e($data->name); ?>' placeholder="name" id="name"
                class="form-control">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" name="email" placeholder="email" value='<?php echo e($data->email); ?>' id="email"
                class="form-control">
        </div>
        <div class="form-group">
            <label for="subject">Subject</label>
            <input type="text" name="subject" placeholder="subject" value='<?php echo e($data->subject); ?>' id="subject"
                class="form-control">
        </div>
        <div class="form-group">
            <label for="message">Message</label>
            <textarea name="message" id="message" class="form-control" placeholder="message"><?php echo e($data->message); ?></textarea>
        </div>

        <button type="submit" class="btn btn-success">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\New folder\app\resources\views/update-message.blade.php ENDPATH**/ ?>