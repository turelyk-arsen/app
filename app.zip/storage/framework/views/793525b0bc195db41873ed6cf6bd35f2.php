<?php $__env->startSection('title-block'); ?>
    Contact page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Contact page</h1>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sit, id repudiandae aliquam facilis eaque illo dolores
        dolor quis aspernatur aperiam et totam maiores optio, deleniti earum perferendis. Voluptatum soluta reiciendis
        corrupti? Laborum molestias magnam nulla eligendi iure accusamus rem est?</p>



    <form action="<?php echo e(route('contact-form')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" placeholder="name" id="name" class="form-control">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" name="email" placeholder="email" id="email" class="form-control">
        </div>
        <div class="form-group">
            <label for="subject">Subject</label>
            <input type="text" name="subject" placeholder="subject" id="subject" class="form-control">
        </div>
        <div class="form-group">
            <label for="message">Message</label>
            <textarea name="message" id="message" class="form-control" placeholder="message"></textarea>
        </div>

        <button type="submit" class="btn btn-success">Send</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\New folder\app\resources\views/contact.blade.php ENDPATH**/ ?>