<?php $__env->startSection('title-block'); ?>
    About page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>About page</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores ipsum incidunt ad quidem rerum dolore dolorum, ducimus sequi blanditiis eveniet voluptatum iste totam nam quis quisquam tempora corrupti perspiciatis deleniti hic nemo atque veritatis officiis aliquam? Non officia repellat, perspiciatis quod laboriosam repellendus alias molestiae nam hic quia perferendis reprehenderit quo cupiditate consequuntur neque, ratione odit voluptatum eligendi, blanditiis aspernatur qui ducimus culpa molestias dolorem. Animi obcaecati facilis, voluptatem sequi quod ratione sunt doloribus ad illum, est autem cupiditate voluptate, cum earum recusandae aperiam deleniti quo odit. Illo nulla fuga laboriosam praesentium, aliquam deleniti officiis, autem enim, facilis omnis necessitatibus.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\Desktop\New folder\app\resources\views/about.blade.php ENDPATH**/ ?>