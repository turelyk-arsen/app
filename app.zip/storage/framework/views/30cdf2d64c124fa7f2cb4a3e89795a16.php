<?php $__env->startSection('aside'); ?>

    <div class="aside">
        <h4>Sidebar</h4>
        <p>One</p>
        <p>Two</p>
        <p>Three</p>
        <?php echo $__env->yieldSection(); ?>
    </div>
<?php /**PATH C:\Users\admin\Desktop\New folder\app\resources\views/inc/aside.blade.php ENDPATH**/ ?>