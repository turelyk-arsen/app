@section('aside')

    <div class="aside">
        <h4>Sidebar</h4>
        <p>One</p>
        <p>Two</p>
        <p>Three</p>
        @show
    </div>
