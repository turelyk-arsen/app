<div class="bg-info">
    <div class="container">
        <h1>HELLO</h1>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Deleniti delectus vero possimus quam, suscipit
            quibusdam ab officia incidunt atque sint!</p>
    </div>
</div>
