@extends('layouts.app')

@section('title-block')
    About page
@endsection

@section('content')
    <h1>Main page</h1>
@endsection

@section('aside')
    @parent
    <p>Two --- only main page</p>
@endsection
