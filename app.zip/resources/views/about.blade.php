@extends('layouts.app')

@section('title-block')
    About page
@endsection

@section('content')
    <h1>About page</h1>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores ipsum incidunt ad quidem rerum dolore dolorum, ducimus sequi blanditiis eveniet voluptatum iste totam nam quis quisquam tempora corrupti perspiciatis deleniti hic nemo atque veritatis officiis aliquam? Non officia repellat, perspiciatis quod laboriosam repellendus alias molestiae nam hic quia perferendis reprehenderit quo cupiditate consequuntur neque, ratione odit voluptatum eligendi, blanditiis aspernatur qui ducimus culpa molestias dolorem. Animi obcaecati facilis, voluptatem sequi quod ratione sunt doloribus ad illum, est autem cupiditate voluptate, cum earum recusandae aperiam deleniti quo odit. Illo nulla fuga laboriosam praesentium, aliquam deleniti officiis, autem enim, facilis omnis necessitatibus.</p>
@endsection